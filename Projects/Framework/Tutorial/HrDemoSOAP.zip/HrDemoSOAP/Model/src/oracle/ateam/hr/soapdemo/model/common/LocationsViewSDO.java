package oracle.ateam.hr.soapdemo.model.common;

public interface LocationsViewSDO {

   public java.lang.Integer getLocationId();

   public void setLocationId(java.lang.Integer value);

   public java.lang.String getStreetAddress();

   public void setStreetAddress(java.lang.String value);

   public java.lang.String getPostalCode();

   public void setPostalCode(java.lang.String value);

   public java.lang.String getCity();

   public void setCity(java.lang.String value);

   public java.lang.String getStateProvince();

   public void setStateProvince(java.lang.String value);

   public java.lang.String getCountryId();

   public void setCountryId(java.lang.String value);


}

