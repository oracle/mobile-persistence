@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.oracle.com/ateam/mobile/persistenceMapping",
                                     elementFormDefault =
                                     javax.xml.bind.annotation.XmlNsForm.QUALIFIED) package oracle.ateam.sample.mobile.dt.model.jaxb;

